package com.example.quizapp;

public class User {

    public String name, email, password;

    public User() {

    }

    public User(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
    }

}
